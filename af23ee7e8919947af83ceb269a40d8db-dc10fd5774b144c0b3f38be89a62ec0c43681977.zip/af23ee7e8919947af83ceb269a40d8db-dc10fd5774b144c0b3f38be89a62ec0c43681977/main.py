import boto3
from botocore.exceptions import ClientError
from jinja2 import Environment, FileSystemLoader
from mail import send_email
import os
import time
import re

ENV = os.environ['env']
SENDER = os.environ['sender']
RECIPIENT = os.environ['recipient']
exceptions = os.environ['exceptions']

ec2_client = boto3.client('ec2')
elb_client = boto3.client('elb')

def get_ec2_tags( instanceid):
	try:
		ec2_tags = ec2_client.describe_tags (
			Filters=[
				{
					'Name': 'resource-id',
					'Values': [instanceid]
				}])
	except ClientError as e:
		print (e.response['Error']['Message'])
	else:
		if len (ec2_tags.get ("Tags")) > 0:
			for tag in ec2_tags.get("Tags"):
				if tag["Key"] == "Name":
					return tag["Value"]

def get_elb_tags(elbname):
	try:
		elb_tags = elb_client.describe_tags (
			LoadBalancerNames=[elbname])
	except ClientError as e:
		print (e.response['Error']['Message'])
	else:
		for i in elb_tags['TagDescriptions']:
			if len (i.get ("Tags")) > 0:
				for tag in i.get ("Tags"):
					if tag["Key"] == "Name":
						return tag["Value"]

def get_ebs_tags(vol):
	try:
		response = ec2_client.describe_volumes (
			VolumeIds=[
				vol,
			],)
	except ClientError as e:
		print (e.response['Error']['Message'])
	else:
		if "Tags" in response['Volumes'][0]:
			tags = response['Volumes'][0]["Tags"]
			if len(tags) > 0:
				for tag in tags:
					if tag["Key"] == "Name":
						return tag["Value"]

def get_rds_arn(rdsname):
	db_instances = boto3.client("rds").describe_db_instances (DBInstanceIdentifier=rdsname)['DBInstances']
	for instance in db_instances:
		if instance['DBInstanceStatus'] == 'available':
			return instance['DBInstanceArn']

def get_rds_tags(rdsname):
	try:
		rds_tags = boto3.client ("rds").list_tags_for_resource (
			ResourceName=get_rds_arn(rdsname),
		)
	except ClientError as e:
		print (e.response['Error']['Message'])
	else:
		if len (rds_tags.get ("TagList")) > 0:
			for tag in rds_tags['TagList']:
				if tag["Key"] == "Name":
					return tag["Value"]

def get_redshift_tags(redshift):
	client = boto3.client("redshift")
	response = client.describe_clusters(
		ClusterIdentifier=redshift
	)
	if response["Clusters"][0]["Tags"]:
		for tag in response["Clusters"][0]["Tags"]:
			if tag["Key"] == "Name":
				return tag["Value"]

def sendmail(subject, body):

	message = {
		"subject": "[{0}] {1} ".format (ENV, subject),
		"body": body,
		"sender": SENDER,
		"recipient": RECIPIENT
	}
	send_email (message)

def get_ebs_status(id):
	ec2 = boto3.resource ('ec2')
	volume = ec2.Volume (id)
	return volume.state

def main():
	client = boto3.client('support')

	response = client.describe_trusted_advisor_checks(
		language='en'
	)
	ec2 = []
	elb = []
	rds = []
	ebs = []
	redshift =[]

	checks = ["Low Utilization Amazon EC2 Instances", "Idle Load Balancers", "Amazon RDS Idle DB Instances",
	 "Underutilized Amazon EBS Volumes",
	 "Underutilized Amazon Redshift Clusters"]

	for i in response["checks"]:
		if i['category'] == "cost_optimizing":
			#print(i)
			if i["name"] in checks:
				client.refresh_trusted_advisor_check (checkId=i['id'])
				refresh = None
				while refresh != "success":
					refresh_status = client.describe_trusted_advisor_check_refresh_statuses (
						checkIds=[i['id']]
					)
					#print(refresh_status)
					refresh = refresh_status["statuses"][0]["status"]
					print(i['name'],refresh)
					if refresh != "success":
						print("Sleeping for 10 secs")
						time.sleep (10)

			results = client.describe_trusted_advisor_check_result (
				checkId=i["id"],
				language='en'
			)
			# print(results["result"].get("categorySpecificSummary",None).get("costOptimizing",None))
			# monthly_savings = results["result"].get("categorySpecificSummary",None).get("costOptimizing",None).get("estimatedMonthlySavings",None)
			# if monthly_savings:
			# 	print (i["name"])
			for data in results["result"]["flaggedResources"]:
				details = data["metadata"]
				if i["name"] == "Low Utilization Amazon EC2 Instances":
					skip = False
					#print(details[1],details[2],details[3],details[4],details[19],details[20],details[21])
					for name in exceptions:
						if details[2].startswith(name):
							print(name,details[2].startswith(name),details[2])
							skip = True
					if not skip:
						ec2.append([details[1],details[2],details[3],details[4],details[19],details[20],details[21],get_ec2_tags(details[1])])
				elif i["name"] == "Idle Load Balancers":
					#print(details[1],details[2],details[3])
					if details[2] != "Low request count":
						elb.append([details[1],details[2],details[3],get_elb_tags(details[1])])
				elif i["name"] == "Amazon RDS Idle DB Instances":
					#print(details[1],details[3],details[4],details[5],details[6])
					rds.append([details[1],details[3],details[4],details[5],details[6],get_rds_tags(details[1])])
				elif i["name"] == "Underutilized Amazon EBS Volumes":
					#print(details[1],details[4],details[5])
					if get_ebs_status(details[1]) == "available":
						ebs.append([details[1],details[4],details[5],get_ebs_tags(details[1])])
				elif i["name"] == "Underutilized Amazon Redshift Clusters":
					#print (details[0], details[4], details[5])
					if details[0] == "Yellow":
						redshift.append ([details[2], details[3], details[4],details[5],get_redshift_tags(details[2])])

	context = {
		'ec2': ec2,
		'elb': elb,
		'ebs': ebs,
		'rds': rds,
		'redshift': redshift
	}

	# jinja template
	THIS_DIR = os.path.dirname (os.path.abspath (__file__))
	j2_env = Environment (loader=FileSystemLoader (THIS_DIR),
						  trim_blocks=True)
	email_body = j2_env.get_template ('email.html').render (context)
	print(email_body)
	subject = "AWS Cleanup Report - DRYRUN"
	sendmail (subject, email_body)

def lambda_handler(event, context):
    main()

if __name__ == '__main__':
    main()